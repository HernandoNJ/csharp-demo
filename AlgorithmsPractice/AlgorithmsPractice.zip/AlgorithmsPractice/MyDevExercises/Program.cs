﻿using AlgorithmsTest;

var ex = new Exercises();
//ex.PrintNewWords();
//ex.PrintArraySumText();
//ex.CheckIntArrayValues();
//ex.TripletsCalculation();
ex.CalculateVeryBigSum();
